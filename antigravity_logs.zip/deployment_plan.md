# UstaadJi Deployment Plan

Since you have Google Cloud credits and want a fast, impressive setup for a hackathon MVP, here are the two best deployment strategies:

## 🏗️ Hosting Suggestions

### Option A: The "All-Google" Stack (Recommended)
Since you already use Vertex AI and have GCP credits, this keeps everything in one ecosystem and looks extremely professional on a resume.
*   **Backend:** **Google Cloud Run**
    *   *Why:* We containerize the FastAPI app using Docker. It scales to zero (costs nothing when unused), handles HTTPS automatically, and has native access to Vertex AI (no need to juggle JSON key files!).
*   **Frontend:** **Firebase Hosting** (or Vercel)
    *   *Why:* Perfect for Single Page Applications (SPAs). It's incredibly fast and free.

### Option B: The "Hacker" Free Stack
If you want to save your credits and rely entirely on generous free tiers.
*   **Backend:** **Render** (Free Tier Web Service)
    *   *Why:* You just connect your GitHub repo and it runs. 
    *   *Catch:* The free tier "sleeps" after 15 minutes of inactivity, meaning the first request takes ~30 seconds to wake up. Also, we have to use a clever workaround to securely pass the Google Service Account JSON file.
*   **Frontend:** **Vercel** or **GitHub Pages**
    *   *Why:* Vercel is much easier for Expo Web apps than GitHub pages because it handles routing automatically, whereas GitHub Pages often throws 404 errors if you refresh the page.

---

## 🚀 Execution Plan (Assuming Option A or Render + Vercel)

Here is the step-by-step plan to get UstaadJi live on the internet.

### Phase 1: Prepare the Backend for Production
1.  **CORS Update:** Update `backend/main.py` to allow requests from the future frontend URL instead of just local testing.
2.  **Dynamic Port Binding:** Ensure uvicorn binds to `0.0.0.0` and respects the `PORT` environment variable (required by both Cloud Run and Render).
3.  **Authentication Handling:** 
    *   *If Cloud Run:* We can ditch the JSON file. Cloud Run natively uses the project's default service account to access Vertex AI.
    *   *If Render:* We will encode the `hackathon-xxx.json` into a Base64 string, put it in a Render Environment Variable, and decode it when the app starts.
4.  **Create a `Dockerfile`:** Write a Dockerfile to package the Python environment, FastAPI code, and the `ustaadji.db` SQLite database. *(Note: SQLite is fine for a hackathon MVP. On cloud platforms, the database will reset to its original state whenever the server restarts, meaning mock bookings will clear, but your provider data will remain).*

### Phase 2: Deploy the Backend
1.  Push the code to a GitHub Repository.
2.  **Deploy:** Connect the repo to Render OR build and deploy to Google Cloud Run.
3.  **Verify:** Ping `https://<your-backend-url>/api/health` to ensure it is live and Vertex AI is responding.

### Phase 3: Prepare the Frontend (Mobile Web Build)
1.  **Environment Variables:** Update `mobile/src/api/client.ts` to replace `localhost:8000` with your new live backend URL (e.g., `https://ustaadji-backend.onrender.com`).
2.  **Export for Web:** Run `npx expo export -p web` to generate a `dist/` folder containing static HTML, CSS, and JS files.

### Phase 4: Deploy the Frontend
1.  **Vercel / Firebase Hosting:** Drag and drop the `dist/` folder into Vercel, or use the Vercel CLI/Firebase CLI to deploy it directly from the terminal.
2.  **Final Verification:** Open the live frontend URL on your phone or desktop browser, send a message to UstaadJi, and confirm the end-to-end AI pipeline works over the internet.

---

**Next Steps:** Let me know which stack you prefer (**Google Cloud Run** vs **Render**), and I will start executing Phase 1 immediately!
