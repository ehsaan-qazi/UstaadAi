# Milestone 4: Mobile Frontend Integration — Implementation Plan

## Overview
Connect the Expo React Native app to the UstaadJi backend APIs and build a premium chat + booking UI.

## Architecture
```
mobile/
├── App.tsx                  # Root with navigation
├── app/                     # Expo Router pages (not used, using direct nav)
├── src/
│   ├── api/
│   │   └── client.ts        # API client (chat + booking)
│   ├── screens/
│   │   ├── ChatScreen.tsx    # Main conversational UI
│   │   └── BookingScreen.tsx # Booking confirmation
│   ├── components/
│   │   ├── MessageBubble.tsx # Chat message component
│   │   ├── TypingIndicator.tsx
│   │   └── ProviderCard.tsx  # Provider info card
│   └── theme/
│       └── colors.ts        # Design tokens
├── index.ts
└── package.json
```

## Key Decisions
1. **Navigation**: React Navigation (stack) for Chat → Booking flow
2. **State**: Local useState + session_id tracking
3. **API Base**: `http://10.0.2.2:8000` (Android emulator) / `http://localhost:8000` (web/iOS)
4. **Design**: Dark theme with emerald accent, glassmorphism cards

## Tasks
- [x] Plan architecture
- [ ] Install dependencies (react-navigation, etc.)
- [ ] Create API client
- [ ] Build ChatScreen with message bubbles
- [ ] Build BookingScreen with confirmation
- [ ] Wire navigation
- [ ] Polish with animations
