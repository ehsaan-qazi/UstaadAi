# 🚀 UstaadJi: AI Service Orchestrator
**Hackathon Project Overview**

UstaadJi is a modern, AI-driven platform designed to organize and automate the informal service economy (plumbers, electricians, AC repair, etc.) in Pakistan. By leveraging advanced AI agent pipelines and geospatial data, UstaadJi bridges the gap between natural language requests and reliable, real-world service fulfillment.

---

## 💡 The Problem & Solution
* **The Problem:** Discovering reliable local service workers relies heavily on word-of-mouth. Pricing is inconsistent, and finding someone nearby in an emergency is highly manual and frustrating.
* **The Solution:** UstaadJi acts as an autonomous digital orchestrator. Users simply type their problem in natural language (e.g., *"Mera AC cooling nahi kar raha, I live in G-13"*). The AI automatically extracts the intent, searches a geographic database of real providers, ranks the best options, estimates a fair market price, and responds in a friendly, conversational tone.

---

## 🧠 The 5-Agent AI Pipeline
The core of UstaadJi is built on **Google's Agent Development Kit (ADK)** using the **Gemini 2.5 Flash** model via **Google Cloud Vertex AI**. It utilizes a Sequential Pipeline of 5 specialized agents:

1. **Intent Agent:** Parses the user's Roman Urdu/English message to extract the service category, location, and urgency.
2. **Discovery Agent:** Uses custom Python tools to geocode the location string into coordinates and queries the database using the Haversine formula to find nearby providers.
3. **Ranking Agent:** Evaluates the discovered providers based on proximity, Google Maps ratings, and review counts to select the top 3 options.
4. **Pricing Agent:** Analyzes the specific problem and local market context to generate a realistic, fair estimated price range (in PKR).
5. **Responder Agent (UstaadJi):** Synthesizes the data from the previous 4 agents into a warm, natural, and bilingual response, guiding the user toward booking.

---

## 🛠️ Tech Stack & Architecture

### Frontend (Mobile & Web)
* **Framework:** React Native with Expo CLI (Cross-platform Android, iOS, and Web).
* **Language:** TypeScript.
* **UI/UX:** Premium dark-themed glassmorphism design with React Navigation, animated message bubbles, and dynamic typing indicators.
* **Hosting:** Vercel (Deployed as an Expo Web build).

### Backend (REST API)
* **Framework:** FastAPI (Python).
* **Database:** SQLite with SQLAlchemy ORM (Seeded with 77+ real-world providers pulled dynamically from the Google Places API).
* **State Management:** In-memory Session Service to maintain multi-turn conversational context.
* **Hosting:** Google Cloud Run (Containerized via Docker, automatically scaling to zero).

### AI & Tools
* **AI Platform:** Google Cloud Vertex AI (Gemini 2.5 Flash).
* **Orchestration:** Google ADK (Agent Development Kit).
* **Location Services:** Google Maps Geocoding API.

---

## 🌟 Key Technical Achievements
* **Zero-Key Architecture:** Deployed securely to Google Cloud Run using Application Default Credentials (ADC), entirely eliminating the need for exposed API keys for Vertex AI.
* **Geospatial Querying:** Implemented the mathematical Haversine formula in the FastAPI backend to calculate exact distances between user locations and providers on a 2D plane.
* **Unified Codebase:** Built a single React Native codebase that seamlessly compiles into both a native mobile experience and a highly responsive shareable web application.
